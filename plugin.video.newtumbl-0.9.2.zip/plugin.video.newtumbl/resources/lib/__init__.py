from . import simpleplugin, newtumblPy, urlquick
newTumbl = newtumblPy.newTumbl
Plugin = simpleplugin.Plugin

